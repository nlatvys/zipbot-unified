create extension if not exists pgcrypto;
create table if not exists chats (id uuid primary key default gen_random_uuid(), zip text not null, user_id uuid, created_at timestamptz default now());
create table if not exists messages (id uuid primary key default gen_random_uuid(), chat_id uuid not null references chats(id) on delete cascade, zip text not null, user_id uuid, role text check (role in ('user','assistant','system')) default 'user', content text not null, created_at timestamptz default now());
alter publication supabase_realtime add table chats; alter publication supabase_realtime add table messages;
create index if not exists idx_messages_chat_id on messages(chat_id); create index if not exists idx_messages_zip_created on messages(zip, created_at); create index if not exists idx_chats_user on chats(user_id); create index if not exists idx_messages_user on messages(user_id);
