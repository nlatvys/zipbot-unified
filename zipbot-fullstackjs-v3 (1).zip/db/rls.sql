alter table if exists chats enable row level security; alter table if exists messages enable row level security;
create policy if not exists chats_select_owner on chats for select to authenticated using ( user_id = auth.uid() );
create policy if not exists messages_select_owner on messages for select to authenticated using ( user_id = auth.uid() );
create policy if not exists chats_insert_owner on chats for insert to authenticated with check ( zip ~ '^\d{5}$' and user_id = auth.uid() );
create policy if not exists messages_insert_owner on messages for insert to authenticated with check ( zip ~ '^\d{5}$' and length(content) <= 2000 and user_id = auth.uid() );
