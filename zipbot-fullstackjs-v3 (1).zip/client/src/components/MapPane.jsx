import React, { useEffect, useRef } from 'react'
export default function MapPane({ zip }){
  const ref=useRef(null), mapRef=useRef(null), markerRef=useRef(null)
  useEffect(()=>{
    const k=import.meta.env.VITE_GOOGLE_MAPS_API_KEY; if(!k||!ref.current) return
    const ensure=()=>new Promise(r=>{ if(window.google?.maps) return r(); const s=document.createElement('script'); s.src=`https://maps.googleapis.com/maps/api/js?key=${k}`; s.async=true; s.onload=r; document.body.appendChild(s) })
    const init=()=>{ if(!mapRef.current){ mapRef.current=new window.google.maps.Map(ref.current,{ center:{lat:27.951,lng:-82.457}, zoom:11, disableDefaultUI:true }) } }
    const geo=()=>{ if(!zip||!window.google) return; const geocoder=new window.google.maps.Geocoder(); geocoder.geocode({ address: zip },(results,status)=>{ if(status==='OK'&&results?.[0]){ const loc=results[0].geometry.location; mapRef.current.setCenter(loc); mapRef.current.setZoom(12); if(markerRef.current) markerRef.current.setMap(null); markerRef.current=new window.google.maps.Marker({ position:loc, map:mapRef.current, title:`ZIP ${zip}` }) } }) }
    (async()=>{ await ensure(); init(); geo() })()
  },[zip])
  return <div ref={ref} style={{width:'100%', height:'100%', borderRadius:12, background:'#eee'}}/>
}
