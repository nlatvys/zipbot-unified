import React, { useEffect, useRef, useState } from 'react'
import GoogleScriptLoader from './GoogleScriptLoader'
function extractZip(components=[]){ for (const c of components){ if (c.types?.includes('postal_code')) return c.long_name } return null }
export default function ZipSearch({ onSelectZip }){
  const inputRef = useRef(null); const [ready,setReady]=useState(false); const [value,setValue]=useState('')
  useEffect(()=>{ if(!ready||!inputRef.current||!window.google) return
    const ac=new window.google.maps.places.Autocomplete(inputRef.current,{ fields:['address_components','geometry','formatted_address'], types:['(regions)'], componentRestrictions:{ country:['us'] } })
    ac.addListener('place_changed',()=>{ const p=ac.getPlace(); const z=extractZip(p.address_components||[]); if(z&&/^\d{5}$/.test(z)) onSelectZip(z); else if(p.geometry){ const gc=new window.google.maps.Geocoder(); gc.geocode({ location:p.geometry.location },(results,status)=>{ if(status==='OK'&&results?.length){ for(const r of results){ const z2=extractZip(r.address_components||[]); if(z2&&/^\d{5}$/.test(z2)){ onSelectZip(z2); return } } } }) } })
  },[ready,onSelectZip])
  const manual=()=>{ const m=value.match(/^\d{5}$/); if(m) onSelectZip(m[0]) }
  return (<div style={{display:'flex', gap:8}}>
    <GoogleScriptLoader onReady={()=>setReady(true)} />
    <input ref={inputRef} value={value} onChange={e=>setValue(e.target.value)} placeholder="Search ZIP or city (e.g., 33701 or Lakeland)" style={{flex:1,padding:12,border:'1px solid #ddd',borderRadius:8}}/>
    <button onClick={manual} style={{padding:'12px 16px',borderRadius:8,background:'#000',color:'#fff'}}>Go</button>
  </div>)
}
