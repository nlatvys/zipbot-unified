import React, { useEffect, useRef, useState } from 'react'
import { supabase } from '../lib/supabaseClient'
async function getOrCreateChat(zip, token){ const res=await fetch('/api/chat',{ method:'POST', headers:{ 'content-type':'application/json','authorization':`Bearer ${token}` }, body:JSON.stringify({ zip }) }); const d=await res.json(); if(!res.ok) throw new Error(d.error||'chat error'); return d.chat }
export default function ChatPane({ zip }){
  const [chatId,setChatId]=useState(null); const [messages,setMessages]=useState([]); const [input,setInput]=useState(''); const subRef=useRef(null)
  useEffect(()=>{ let mounted=true; (async()=>{ const session=(await supabase.auth.getSession()).data.session; if(!session) return; const chat=await getOrCreateChat(zip, session.access_token); if(!mounted) return; setChatId(chat.id); const { data:rows } = await supabase.from('messages').select('*').eq('chat_id',chat.id).order('created_at',{ascending:true}); setMessages(rows||[]); subRef.current = supabase.channel(`messages-${zip}-${session.user.id}`).on('postgres_changes',{ event:'INSERT', schema:'public', table:'messages', filter:`chat_id=eq.${chat.id}` }, (payload)=> setMessages(m=>[...m,payload.new])).subscribe() })(); return ()=>{ if(subRef.current) supabase.removeChannel(subRef.current) } },[zip])
  const send = async () => { const text=input.trim(); if(!text||!chatId) return; setInput(''); const temp={ id:`temp-${Date.now()}`, chat_id:chatId, zip, role:'user', content:text, created_at:new Date().toISOString() }; setMessages(m=>[...m,temp]); const session=(await supabase.auth.getSession()).data.session; const res=await fetch('/api/message',{ method:'POST', headers:{ 'content-type':'application/json','authorization':`Bearer ${session?.access_token}` }, body:JSON.stringify({ chat_id:chatId, zip, content:text }) }); const d=await res.json(); if(!res.ok){ setMessages(m=>m.filter(x=>x.id!==temp.id)); alert(d.error||'Failed to send') } else { fetch('/api/assistant',{ method:'POST', headers:{ 'content-type':'application/json','authorization':`Bearer ${session?.access_token}` }, body:JSON.stringify({ chat_id:chatId, zip, prompt:text }) }).catch(()=>{}) } }
  return (<div style={{display:'flex',flexDirection:'column',height:280}}>
    <div style={{flex:1,overflow:'auto',padding:8,border:'1px solid #eee',borderRadius:8,background:'#fff'}}>
      {messages.map(m=>(<div key={m.id} style={{textAlign:m.role==='user'?'right':'left',margin:'6px 0'}}><span style={{display:'inline-block',padding:'8px 12px',borderRadius:12,background:'#f3f4f6'}}>{m.content}</span></div>))}
    </div>
    <div style={{marginTop:8,display:'flex',gap:8}}>
      <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter'?send():null} placeholder={`Ask about ${zip}…`} style={{flex:1,padding:10,border:'1px solid #ddd',borderRadius:8}}/>
      <button onClick={send} style={{padding:'10px 14px',borderRadius:8,background:'#000',color:'#fff'}}>Send</button>
    </div>
  </div>)
}
