import React, { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'
import SignInCard from './SignInCard'
export default function AuthGate({ children }){
  const [ready,setReady]=useState(false); const [user,setUser]=useState(null)
  useEffect(()=>{ supabase.auth.getUser().then(({data})=>{ setUser(data?.user||null); setReady(true) }); const { data:sub }=supabase.auth.onAuthStateChange((_e,s)=>setUser(s?.user||null)); return ()=>sub.subscription.unsubscribe() },[])
  if(!ready) return <div>Loading…</div>
  if(!user) return <SignInCard />
  return children
}
