import React, { useState } from 'react'
import { supabase } from '../lib/supabaseClient'
export default function SignInCard(){
  const [email,setEmail]=useState(''); const [sent,setSent]=useState(false); const [err,setErr]=useState('')
  const send=async()=>{ setErr(''); const redirect=`${window.location.origin}/auth/callback`; const { error } = await supabase.auth.signInWithOtp({ email, options:{ emailRedirectTo: redirect } }); if(error) setErr(error.message); else setSent(true) }
  return (<div style={{border:'1px solid #eee',padding:16,borderRadius:12,background:'#fff'}}>
    <h3>Sign in to start a chat</h3><p style={{color:'#666'}}>We’ll send you a secure magic link.</p>
    <div style={{display:'flex',gap:8,marginTop:8}}>
      <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" style={{flex:1,padding:10,border:'1px solid #ddd',borderRadius:8}}/>
      <button onClick={send} style={{padding:'10px 14px',borderRadius:8,background:'#000',color:'#fff'}}>Send link</button>
    </div>
    {sent && <p style={{color:'green'}}>Check your email for the sign-in link.</p>}
    {err && <p style={{color:'red'}}>{err}</p>}
  </div>)
}
