import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Consumer from './pages/Consumer'
import ZipPage from './pages/ZipPage'

export default function App(){
  return (
    <div style={{maxWidth: 1040, margin: '0 auto', padding: 16, fontFamily: 'system-ui, -apple-system, Segoe UI, Roboto'}}>
      <nav style={{display:'flex', justifyContent:'space-between', marginBottom:16}}>
        <Link to="/">ZIPBOT</Link>
        <div style={{display:'flex', gap:12}}>
          <Link to="/consumer">Consumer</Link>
          <a href="/pro" target="_blank" rel="noreferrer">Pro</a>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<Consumer />} />
        <Route path="/consumer" element={<Consumer />} />
        <Route path="/zip/:zip" element={<ZipPage />} />
        <Route path="*" element={<div>Not found</div>} />
      </Routes>
    </div>
  )
}
