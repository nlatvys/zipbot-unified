import React from 'react'
import { useNavigate } from 'react-router-dom'
import ZipSearch from '../components/ZipSearch'
export default function Consumer(){ const nav=useNavigate(); return (<main style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16,alignItems:'stretch'}}>
  <section style={{border:'1px solid #eee',padding:16,borderRadius:12,background:'#fff'}}>
    <h1 style={{fontSize:28,margin:0}}>Your ZIP essentials in one place</h1>
    <p style={{color:'#666'}}>Schools, utilities, DMV, taxes, parks — and quick answers from ZIPBOT.</p>
    <ZipSearch onSelectZip={(zip)=> nav(`/zip/${zip}`)} />
    <div style={{marginTop:8,color:'#888',fontSize:12}}>Examples: 33606, 33701, 33511, 34655, 33813, 34609</div>
  </section>
  <aside style={{border:'1px solid #eee',padding:16,borderRadius:12,background:'#fff'}}>
    <div style={{height:320,borderRadius:12,background:'#e5e7eb',position:'relative',overflow:'hidden'}}>
      <div style={{position:'absolute',right:12,top:12,background:'#fff',borderRadius:8,padding:'4px 8px',boxShadow:'0 1px 3px rgba(0,0,0,0.08)'}}>Legend • Landmarks</div>
    </div>
    <div style={{fontSize:12,color:'#888',marginTop:8}}>Map will center on the ZIP you select.</div>
  </aside>
</main>) }
