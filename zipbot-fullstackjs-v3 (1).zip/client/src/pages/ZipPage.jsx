import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import MapPane from '../components/MapPane'
import AuthGate from '../components/AuthGate'
import ChatPane from '../components/ChatPane'

function LinkList({ title, items }){
  if (!items || !items.length) return null
  return (
    <section style={{border:'1px solid #eee', padding:12, borderRadius:12, background:'#fff'}}>
      <h3 style={{marginTop:0}}>{title}</h3>
      <ul>{items.map((it,i)=>(<li key={i}><a href={it.url} target="_blank" rel="noreferrer">{it.label}</a></li>))}</ul>
    </section>
  )
}

export default function ZipPage(){
  const { zip } = useParams()
  const [data, setData] = useState(null)
  useEffect(()=>{ fetch(`/api/pilot/${zip}`).then(r=>r.json()).then(d=> setData(d.data || null)) },[zip])
  return (
    <main style={{display:'grid', gap:16}}>
      <header><h1 style={{margin:0}}>ZIP {zip}</h1>{!data && <p style={{color:'#b91c1c'}}>We don't have curated links for this ZIP yet. Try 33606, 33611, 33701.</p>}</header>
      <div style={{display:'grid', gridTemplateColumns:'2fr 1fr', gap:16}}>
        <div style={{border:'1px solid #eee', padding:12, borderRadius:12, background:'#fff', height:420}}><MapPane zip={zip} /></div>
        <aside style={{display:'grid', gap:8}}>
          <LinkList title="Schools" items={data?.schools} />
          <LinkList title="Utilities" items={data?.utilities} />
          <LinkList title="DMV / Licensing" items={data?.dmv} />
          <LinkList title="Taxes" items={data?.taxes} />
          <LinkList title="Parks" items={data?.parks} />
          <LinkList title="Listings (ListCastTV)" items={data?.listings} />
        </aside>
      </div>
      <section style={{border:'1px solid #eee', padding:12, borderRadius:12, background:'#fff'}}>
        <h3 style={{marginTop:0}}>Ask ZIPBOT about {zip}</h3>
        <AuthGate><ChatPane zip={zip} /></AuthGate>
      </section>
    </main>
  )
}
