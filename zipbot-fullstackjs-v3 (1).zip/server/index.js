import express from "express"
import cors from "cors"
import morgan from "morgan"
import dotenv from "dotenv"
import path from "path"
import { fileURLToPath } from "url"
import { createClient } from "@supabase/supabase-js"
import fs from "fs"

dotenv.config()
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const app = express()
app.use(cors())
app.use(express.json({ limit: "1mb" }))
app.use(morgan("dev"))

const SUPABASE_URL = process.env.SUPABASE_URL
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY
const LISTCASTAI_URL = process.env.LISTCASTAI_URL || ""
const LISTCASTAI_API_KEY = process.env.LISTCASTAI_API_KEY || ""

function userClient(req){
  const auth = req.headers["authorization"] || ""
  return createClient(SUPABASE_URL, SUPABASE_ANON_KEY, { global: { headers: { Authorization: auth } } })
}
function adminClient(){
  return createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
}

function readPilot(){
  const p = path.join(__dirname, "data", "pilot.json")
  try { return JSON.parse(fs.readFileSync(p, "utf-8")) } catch { return {} }
}

app.get("/api/pilot/:zip", (req, res) => {
  const data = readPilot()[req.params.zip] || null
  res.json({ zip: req.params.zip, data })
})

app.post("/api/chat", async (req, res) => {
  const supabase = userClient(req)
  const { zip } = req.body || {}
  if (!zip || !/^\d{5}$/.test(zip)) return res.status(400).json({ error: "Invalid payload" })
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return res.status(401).json({ error: "Unauthorized" })
  const { data: existing, error: selErr } = await supabase.from("chats").select("*").eq("zip", zip).eq("user_id", user.id).order("created_at", { ascending: false }).limit(1)
  if (selErr) return res.status(500).json({ error: selErr.message })
  if (existing && existing[0]) return res.json({ chat: existing[0] })
  const { data: created, error: insErr } = await supabase.from("chats").insert({ zip, user_id: user.id }).select("*").single()
  if (insErr) return res.status(500).json({ error: insErr.message })
  res.json({ chat: created })
})

const MAX_LEN = 1000, BANNED = ["kill","violence","bomb"], RATE_PER_MIN = 5, RATE_PER_DAY = 50

app.post("/api/message", async (req, res) => {
  const supabase = userClient(req)
  const { chat_id, zip, content } = req.body || {}
  if (!chat_id || !zip || !/^\d{5}$/.test(zip)) return res.status(400).json({ error: "Invalid payload" })
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return res.status(401).json({ error: "Unauthorized" })
  const text = (content || "").trim()
  if (!text) return res.status(400).json({ error: "Empty message" })
  if (text.length > MAX_LEN) return res.status(413).json({ error: "Message too long" })
  const lower = text.toLowerCase(); for (const w of BANNED){ if (lower.includes(w)) return res.status(422).json({ error: "Message blocked by moderation" }) }
  const now = new Date()
  const minuteAgo = new Date(now.getTime() - 60*1000).toISOString()
  const dayAgo = new Date(now.getTime() - 24*60*60*1000).toISOString()
  const { count: cMin, error: e1 } = await supabase.from("messages").select("id", { count: "exact", head: true }).eq("user_id", user.id).eq("zip", zip).gte("created_at", minuteAgo)
  if (e1) return res.status(500).json({ error: e1.message })
  const { count: cDay, error: e2 } = await supabase.from("messages").select("id", { count: "exact", head: true }).eq("user_id", user.id).eq("zip", zip).gte("created_at", dayAgo)
  if (e2) return res.status(500).json({ error: e2.message })
  if ((cMin||0) >= RATE_PER_MIN) return res.status(429).json({ error: "Rate limit (per minute) exceeded" })
  if ((cDay||0) >= RATE_PER_DAY) return res.status(429).json({ error: "Rate limit (per day) exceeded" })
  const { data: inserted, error: insErr } = await supabase.from("messages").insert({ chat_id, zip, user_id: user.id, role: "user", content: text }).select("*").single()
  if (insErr) return res.status(500).json({ error: insErr.message })
  res.json({ ok: true, message: inserted })
})

app.post("/api/assistant", async (req, res) => {
  const uclient = userClient(req), aclient = adminClient()
  const { chat_id, zip, prompt } = req.body || {}
  if (!chat_id || !zip || !/^\d{5}$/.test(zip)) return res.status(400).json({ error: "Invalid payload" })
  const { data: { user } } = await uclient.auth.getUser()
  if (!user) return res.status(401).json({ error: "Unauthorized" })
  const { data: history, error: histErr } = await uclient.from("messages").select("role,content,created_at").eq("chat_id", chat_id).order("created_at", { ascending: true }).limit(12)
  if (histErr) return res.status(500).json({ error: histErr.message })
  const pilot = readPilot()[zip] || null
  const payload = { zip, prompt, history, context: { pilot_links: pilot || {} } }
  let answer = ""
  if (LISTCASTAI_URL){
    try {
      const resp = await fetch(LISTCASTAI_URL, { method: "POST", headers: { "content-type": "application/json", ...(LISTCASTAI_API_KEY ? { "authorization": `Bearer ${LISTCASTAI_API_KEY}` } : {}) }, body: JSON.stringify(payload) })
      if (resp.ok){ const d = await resp.json(); answer = d.text || d.answer || "" }
    } catch {}
  }
  if (!answer){
    const parts = []; parts.push(`Here are useful resources for ZIP ${zip}:`)
    if (pilot){
      const order = ["schools","utilities","dmv","taxes","parks","listings"]
      for (const k of order){
        if (Array.isArray(pilot[k]) && pilot[k].length){ parts.push(`\n${k.toUpperCase()}\n` + pilot[k].slice(0,3).map(it=>`• ${it.label}: ${it.url}`).join("\n")) }
      }
      parts.push("\nTell me what you’re trying to do (e.g., transfer utilities, register a new car, find elementary schools).")
    } else { parts.push("No curated links yet for this ZIP. Try a nearby ZIP or ask a specific question.") }
    answer = parts.join("\n")
  }
  const { error: insErr } = await aclient.from("messages").insert({ chat_id, zip, user_id: user.id, role: "assistant", content: answer })
  if (insErr) return res.status(500).json({ error: insErr.message })
  res.json({ ok: true })
})

const distPath = path.join(__dirname, "..", "client", "dist")
if (fs.existsSync(distPath)){
  app.use(express.static(distPath))
  app.get("*", (_req, res) => res.sendFile(path.join(distPath, "index.html")))
}
const PORT = process.env.PORT || 3000
app.listen(PORT, () => console.log(`ZIPBOT server running on :${PORT}`))
