# ZIPBOT — FULLSTACK_JS (React + Express) v2

Use this when Next.js is blocked. This repo runs as a single Express server that serves the built React app and provides API routes compatible with Supabase + ListCastAI.

## Setup
1) **Supabase** → run `db/schema.sql` then `db/rls.sql`. Enable Email (magic link) auth. Add redirect: `/auth/callback`.
2) **Replit Secrets**
Server:
- SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY
- LISTCASTAI_URL (optional), LISTCASTAI_API_KEY (optional)
- PORT = 3000
Client:
- VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY, VITE_GOOGLE_MAPS_API_KEY

## Run
```bash
npm install
npm run build
npm start
```
Visit `/consumer`, choose a ZIP, sign in, and chat.
